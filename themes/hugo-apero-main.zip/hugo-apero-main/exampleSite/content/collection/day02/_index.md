---
title: "Day 02"
# list or single layouts are possible
layout: single-series # list, list-sidebar, single-series
weight: 3
publishDate: 2021-01-22
date: 2021-01-26
subtitle: "All about Day 02 of 'Introduce Yourself Online'."
description: |
  day two
excerpt: 
author: Alison Hill
show_post_thumbnail: true
show_author_byline: false
show_post_date: false
---

If you choose `layout: single-series`, you can add markdown text here and it will be the landing page for this nested subsection.
